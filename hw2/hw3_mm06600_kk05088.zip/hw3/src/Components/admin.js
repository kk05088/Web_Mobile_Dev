

export default function Todo({todo, index}){
    return (
    <div>
        You are an admin, this is conditional routing example
    </div>)
}