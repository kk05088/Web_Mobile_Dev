import React from 'react';
// import ReactDOM from 'react-dom/client';
import ProjectPage from './projectpage';



export default function projectpage({todo, index}){
    return (
    <div>
        <ProjectPage/>

    </div>)
}